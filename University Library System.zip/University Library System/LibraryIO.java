//packages
import java.util.*;

//A class that takes user input from the keyboard (deals with displaying prompts to users and taking in inputs)
public class LibraryIO
{
   private static final int MAX_OPTION = 15;
   private static final int MIN_OPTION = 0;
   private Scanner in;
   
   public LibraryIO()
   {
      in = new Scanner(System.in);
   }
   
   /*
   * A method that displays the menu for the library system
   */
   public void showMenu()
   {
      System.out.println("WELCOME!!!!");
      System.out.println();
      System.out.println("1...Register a student to the system");
      System.out.println("2...Register a staff to the system");
      System.out.println("3...Remove a user from the system");
      System.out.println("4...Add a book to the library catalogue");
      System.out.println("5...Remove a book from the library catalogue");
      System.out.println("6...Grant a short-term loan to a user");
      System.out.println("7...Grant a long-term loan to a user");
      System.out.println("8...Return a book to the library");
      System.out.println("9...Retrieve book(s) by author");
      System.out.println("10..Retrieve book(s) by title");
      System.out.println("11..Retrieve book(s) by classification code");
      System.out.println("12..List all the books in the library catalogue");
      System.out.println("13..List all the users in the system");
      System.out.println("14..List all the loans ever made");
      System.out.println("15..List all the overdue books");
      System.out.println("0...Exit Application");
      System.out.println();
   }
   
   /*
   * A method that prompts the user for a a choice and stores the user's choice
   */
   public int getChoice()
   {
      System.out.print("Please enter a choice: ");
      int choice = in.nextInt();
      System.out.println();
      
      while((choice < MIN_OPTION) || (choice > MAX_OPTION))
      {
         System.out.print("Invalid choice. Please enter a choice between 0 and 15: ");
         choice = in.nextInt();
         System.out.println();
      }
      
      return choice;
   }
   
   /*
   * A method that prompts the user for a (user's) name and stores the user's input
   */
   public String getName()
   {
      System.out.print("Please enter a name: ");
      String aName = in.next();
      System.out.println();
      
      return aName;
   }
   
   /*
   * A method that prompts the user for a user's identification number and stores the user's input
   */
   public String getID()
   {
      System.out.print("Please enter an identification number: ");
      String id = in.next();
      System.out.println();
      
      return id;
   }
   
   /*
   * A method that prompts the user for a book's author and stores the user's input
   */
   public String getAuthor()
   {
      System.out.print("Please enter an author: ");
      String anAuthor = in.next();
      System.out.println();
      
      return anAuthor;
   }
   
   /*
   * A method that prompts the user for a book's title and stores the user's input
   */
   public String getTitle()
   {
      System.out.print("Please enter a title: ");
      String aTitle = in.next();
      System.out.println();
      
      return aTitle;
   }
   
   /*
   * A method that prompts the user for a book's classification code and stores the user's input
   */
   public String getClassCode()
   { 
      System.out.print("Please enter a classification code in the format (XX999.999): ");
      String classCode = in.next();
      System.out.println();
      
      return classCode;
   }

}
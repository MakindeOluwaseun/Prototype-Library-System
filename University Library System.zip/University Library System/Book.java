public class Book
{
   private String author; //the author of the book
   private String title; //the title of the book
   private String classificationCode; //the classification code of the book
   private User aUser; //the current user assigned to the book if any
   private String[] bookStatus = {"Available", "Loaned"}; //an array which describes the statuses a book could take on
   
   /*
   * A user-defined constructor method
   * @param anAuthor the author of a book
   * @param aTitle the title of a book
   * @param aClassCode the classification code of a book
   */
   public Book(String anAuthor, String aTitle, String aClassCode)
   {
      author = anAuthor;
      title = aTitle;
      classificationCode = aClassCode;
      aUser = null;
   }
   
   /*
   * An accessor method which returns the author of a specified book
   * @return the author of the specified book
   */
   public String getAuthor()
   {
      return author;
   }
   
   /*
   * An accessor method which returns the title of a specified book
   @return the title of the specified book
   */
   public String getTitle()
   {
      return title;
   }
   
   /*
   * An accessor method which returns the classification code of a specified book
   * @return the classification code of the specified book
   */
   public String getClassificationCode()
   {
      return classificationCode;
   }
   
   /*
   * An accessor method which returns the user currently assigned to a specified book if any
   * @return the user of the specified book
   */
   public User getUser()
   {
      return this.aUser;
   }
   
   /*
   * A method that sets a user to a book at the time of loan
   * @param aUser the user to be set to the book
   */
   public void setUser(User aUser)
   {
      this.aUser = aUser;
   }
   
   /*
   * A method that gets the details of the user of a book if any
   * @return the details of the user if any
   */
   public String getUserInfo()
   {
      String userDetails = null;
      
      if(this.aUser != null)
      {
         userDetails = "\n" + "Name: " + aUser.getName() + "\n" + "Identification number: " + aUser.getID();
      }
      
      else
      {
         userDetails = "No user assigned to book yet";
      }
      
      return userDetails;
   }
   
   /*
   * A method that returns the current status of a book depending on whether a user is assigned to it
   * @return the current status of a book
   */
   public String getBookStatus()
   {
      String status = null;
      
      if(this.getUser() == null)
      {
         status = bookStatus[0];
      }
      
      else
      {
         status = bookStatus[1];
      }
      
      return status;
   }
   
   /*
   * A method that returns the current state of the book object
   * @return the current state of the book object
   */
   public String toString()
   {
      String state = "Author: " + this.getAuthor() + "\n" + "Title: " + this.getTitle() + "\n"
                     + "Classification code: " + this.getClassificationCode() + "\n"
                     + "User: " + this.getUserInfo() + "\n" + "Status: " 
                     + this.getBookStatus() + "\n";
                     
      return state;
   }
}
//A sub-category of the type User (i.e. a sub-class)
public class Staff extends User
{
   //constants
   private static final int MAX_BORROW_LIMIT = 5; //the maxmum borrow limit of a student
   
   /*
   * A user-defined constructor method
   */
   public Staff(String aName, String anID)
   {
      super(aName, anID, MAX_BORROW_LIMIT);
   }
   
   /*
   * A method that returns the current state of a Staff
   * @return the current state of a Staff
   */
   public String toString()
   {
      String state = super.toString();
      return state;
   }
}

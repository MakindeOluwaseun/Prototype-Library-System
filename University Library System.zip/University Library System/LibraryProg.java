//packages
import java.text.ParseException;

public class LibraryProg
{
   public static void main(String[] args)
   {
      LibraryControl c = new LibraryControl();
      
      try //tries this method and catches a Parse exception if any.
      {
         c.startProg();
      }
      
      catch(ParseException e)
      {
         System.out.println(e);
      }
   }
      
         
}
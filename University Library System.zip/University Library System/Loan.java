public abstract class Loan
{
   private User aUser; //the user being granted a loan
   private Book aBook; //the book to be loaned
   private String loanStartDate; // the start date of the loan
   private String loanEndDate; //the finish date of the loan
   
   
   /*
   * A user-defined constructor method
   */
   public Loan(User aUser, Book aBook)
   {
      this.aUser = aUser;
      this.aBook = aBook;
      loanStartDate = null;
      loanEndDate = null;
      this.giveUserBook(this.aBook, this.aUser);
      //remember to create a condition in the method that creates a loan object in the LibrarySystem
      //class to prevent the loan object from being constructed if the appropriate conditions aren't
      //met (i.e. check if maximum borrow limit reached and if the book specified is available for
      //loan
   }
   
   /*
   * A method that assigns a book to a user and vice-versa
   * @param aBook the book to be assigned
   * @param aUser the user to be assigned
   */
   public void giveUserBook(Book aBook, User aUser)
   {
      aUser.addBookToList(aBook);         
   }
   
   /*
   * A method that get's a user's information
   * @return the user's information
   */
   public String getUserInfo()
   {
      String details = "Name: " + aUser.getName() + "\n" + "ID: " + aUser.getID() + "\n";
      return details; 
   }
   
   /*
   * A method that returns a books information
   * @return the book's information
   */
   public String getBookInfo()
   {
      String details = "Author: " + aBook.getAuthor() + "\n" + "Title: " + aBook.getTitle() + "\n"
                        + "Classification code: " + aBook.getClassificationCode() + "\n";
                        
      return details;
   }
   
   /*
   * A method that returns the start date of a loan
   * @return the start date of the loan
   */
   public String getLoanStartDate()
   {
      return loanStartDate;
   }
   
   /*
   * A method that returns the end date of a loan
   * @return the end date of the loan
   */
   public String getLoanEndDate()
   {
      return loanEndDate;
   }
   
   /*
   * A method that sets the start date of a loan object
   * @param aDate the start date of the loan
   */
   public void setLoanStartDate(String aDate)
   {
      loanStartDate = aDate;
   }
   
   /*
   * A method that sets the end date of a loan object
   * @param aDate the end date of a loan
   */
   public void setLoanEndDate(String aDate)
   {
      loanEndDate = aDate;
   }

   
   /*
   * A method that returns the current state of a loan
   * @return the current state of a loan
   */
   public String toString()
   {
      String state = "User details: " + this.getUserInfo() + "\n" + "Book Details: "
                     + this.getBookInfo() + "\n" + "Loan Start: " + this.getLoanStartDate() + "\n"
                     + "Loan End: " + this.getLoanEndDate() + "\n";
                     
      return state;
   }
      
}

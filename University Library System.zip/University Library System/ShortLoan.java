//packages
import java.util.Date;

//A sub-category of the type loan (i.e. a sub-class of Loan)
public class ShortLoan extends Loan
{
   //constants
   private static final int TIME_LIMIT = 7; //the maximum amount of time all users can borrow a book for
                                           //(it is represented in days)
                                           
   private static final int MISSING_YEARS = 1900; //when the getYear() mehtod of the date class is called,
                                                  //it subtracts 1990 from the current year however, due
                                                  //to the fact that the original current year value is 
                                                  //needed, this constant exists to make up that
                                                  //difference and allow the appropriate year value to be
                                                  //printed
                                                  
   private static final int MISSING_MONTH = 1; //the getMonth() method the date class returns the current month - 1
                                               //thus this is needed to compiment the getMonth() value
   
   /*
   * A user-defined constructor method
   */
   public ShortLoan(User aUser, Book aBook)
   {
      super(aUser, aBook);
      this.setLoanStartDate(generateStartDate());
      this.setLoanEndDate(generateEndDate());
   }
   
   /*
   * A method that generates the start date of a loan using appropriate varaibles
   * @return the start date of a loan
   */
   public String generateStartDate()
   {
      Date aDate = new Date();
      String today = aDate.getDate() + "/" + (aDate.getMonth() + MISSING_MONTH) + "/" + (aDate.getYear() + MISSING_YEARS);
      return today;
   }
   
   /*
   * A method that returns the end date of a loan using apppropriate variables
   * @return the end date of a loan
   */
   public String generateEndDate()
   {
      Date aDate = new Date();
      aDate.setDate(aDate.getDate() + TIME_LIMIT);
      
      String endDate = aDate.getDate() + "/" + (aDate.getMonth() + MISSING_MONTH) + "/" + (aDate.getYear() + MISSING_YEARS);
      return endDate;
   }
   
   /*
   * A method that returns the current state of a short loan
   * @return the current state of a short loan
   */
   public String toString()
   {
      String state = super.toString();
      return state;
   }
}
//packages
import java.util.Date;

//A sub-category of the type loan (i.e. a sub-class of Loan)
public class LongLoan extends Loan
{
   //constants
   private static final int STUDENT_TIME_LIMIT_IN_MONTHS = 3; //the maximum amount of time a student can borrow a book for
   
   private static final int STAFF_TIME_LIMIT_IN_MONTHS = 6; //the maximum amount of time a staff can borrow a book for
   
   private static final int AMOUNT_OF_DAYS_IN_MONTH = 31; //it is assumed that every month in a year has 31 days
   
   private static final int STUDENT_TIME_LIMIT_IN_DAYS = STUDENT_TIME_LIMIT_IN_MONTHS * AMOUNT_OF_DAYS_IN_MONTH; //the maximum amount of time a student can borrow a book for
   private static final int STAFF_TIME_LIMIT_IN_DAYS = STAFF_TIME_LIMIT_IN_MONTHS * AMOUNT_OF_DAYS_IN_MONTH; //the maximum amount of time a staff can borrow a book for
                                                                                      
   private static final int MISSING_YEARS = 1900; //when the getYear() mehtod of the date class is called,
                                                  //it subtracts 1990 from the current year however, due
                                                  //to the fact that the original current year value is 
                                                  //needed, this constant exists to make up that
                                                  //difference and allow the appropriate year value to be
                                                  //printed
                                                  
   private static final int MISSING_MONTH = 1; //the getMonth() method the date class returns the current month - 1
                                               //thus this is needed to compiment the getMonth() value

   
   /*
   * A user-defined constructor method
   */
   public LongLoan(User aUser, Book aBook)
   {
      super(aUser, aBook);
      this.setLoanStartDate(generateStartDate());
      this.setLoanEndDate(generateEndDate(aUser));
   }
   
   /*
   * A method that generates the start date of a loan using appropriate variables
   * @return the start date of a loan
   */
   public String generateStartDate()
   {
      Date aDate = new Date();
      String today = aDate.getDate() + "/" + (aDate.getMonth() + MISSING_MONTH) + "/" + (aDate.getYear() + MISSING_YEARS);
      return today;
   }
   
   /*
   * A method that generates the end date of a loan using appropriate variables
   * @return the end date of a loan
   */
   public String generateEndDate(User aUser)
   {
      String endDate = null;
      if(aUser instanceof Student)
      {
      
         Date aDate = new Date();
         aDate.setDate(aDate.getDate() + STUDENT_TIME_LIMIT_IN_DAYS);
      
         endDate = aDate.getDate() + "/" + (aDate.getMonth() + MISSING_MONTH) + "/" + (aDate.getYear() + MISSING_YEARS);
      }
      
      else
      {
         Date aDate = new Date();
         aDate.setDate(aDate.getDate() + STAFF_TIME_LIMIT_IN_DAYS);
      
         endDate = aDate.getDate() + "/" + (aDate.getMonth() + MISSING_MONTH) + "/" + (aDate.getYear() + MISSING_YEARS);
      }
      
      return endDate;
   }
   
   /*
   * A method that returns the current state of a long loan
   * @return the current state of a long loan
   */
   public String toString()
   {
      String state = super.toString();
      return state;
   }
}

//A sub-category of the type Student (i.e. a sub-class)
public class Student extends User
{
   //constants
   private static final int MAX_BORROW_LIMIT = 3; //the maximum borrow limit of a student
   
   /*
   * A user-defined constructor method
   */
   public Student(String aName, String anID)
   {
      super(aName, anID, MAX_BORROW_LIMIT);
   }
   
   /*
   * A method that returns the current state of a Student
   * @return the current state of a Student
   */
   public String toString()
   {
      String state = super.toString();
      return state;
   }
}
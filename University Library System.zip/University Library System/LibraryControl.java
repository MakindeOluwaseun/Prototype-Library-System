//packages
import java.text.ParseException;

//A control class that interacts with both the data classes and the interface class
public class LibraryControl
{
   private LibrarySystem system;
   private User aUser;
   private Student aStudent;
   private Staff aStaff;
   private Book aBook;
   private Loan aLoan;
   private ShortLoan aShortLoan;
   private LongLoan aLongLoan;
   private LibraryIO io;
   
   /*
   * A method that starts the library system program
   * @throws ParseException
   */
   public void startProg() throws ParseException
   {
      io = new LibraryIO();
      this.createSystem();
      this.runInterface();
   }
   
   /*
   * A method that runs the interface for the library system
   */
   private void runInterface() throws ParseException
   {
      int choice = 0;
      
      do
      {
         io.showMenu();
         choice = io.getChoice();
         
         switch(choice)
         {
            case 1: this.addStudent();
                    break;
                    
            case 2: this.addStaff();
                    break;
                    
            case 3: this.removeUser();
                    break;
                    
            case 4: this.addBook();
                    break;
                    
            case 5: this.removeBook();
                    break;
            
            case 6: this.giveShortLoan();
                    break;
                    
            case 7: this.giveLongLoan();
                    break;
                    
            case 8: this.returnBook();
                    break;
            
            case 9: this.returnBooksByAuthor();
                    break;
                    
            case 10: this.returnBooksByTitle();
                     break;
                     
            case 11: this.returnBooksByClassCode();
                     break;
                     
            case 12: this.listAllBooks();
                     break;
                     
            case 13: this.listAllUsers();
                     break;
                     
            case 14: this.listAllLoans();
                     break;
                     
            case 15: this.listAllBooksOverdue();
                     break;
         }
      }
      
      while(choice != 0);
      this.exitProg();
   }
   
   /*
   * A method that initialises an instance of the LibrarySystem class
   */
   private void createSystem()
   {
      system = new LibrarySystem();
   }
   
   /*
   * A method that quits the application
   */
   private void exitProg()
   {
      System.exit(0);
   }
   
   /*
   * A method that adds a student to the list of users
   */
   private void addStudent()
   {
      String aName = io.getName();
      String id = io.getID();
      
      aStudent = new Student(aName, id);
      
      System.out.println("Is added: " + system.addAUser(aStudent));
      System.out.println();
   }
   
   /*
   * A method that adds a staff to the list of users
   */
   private void addStaff()
   {
      String aName = io.getName();
      String id = io.getID();
      
      aStaff = new Staff(aName, id);
      
      System.out.println("Is added: " + system.addAUser(aStaff));
      System.out.println();
   }
   
   /*
   * A method that removes a user from the list of users
   */
   private void removeUser()
   {
      String id = io.getID();
      
      System.out.println("Is removed: " + system.removeUser(id));
      System.out.println(); 
   }
   
   /*
   * A method that adds a book to the library catalogue
   */
   private void addBook()
   {
      String anAuthor = io.getAuthor();
      String aTitle = io.getTitle();
      String classCode = io.getClassCode();
      
      aBook = new Book(anAuthor, aTitle, classCode);
      
      System.out.println("Is added: " + system.addBook(aBook));
      System.out.println();
   }
   
   /*
   * A method that removes a book from te library catalogue
   */
   private void removeBook()
   {
      String anAuthor = io.getAuthor();
      String aTitle = io.getTitle();
      String classCode = io.getClassCode();
      
      System.out.println("Is removed: " + system.removeBook(anAuthor, aTitle, classCode));
      System.out.println();
   }
   
   /*
   * A method that grants a short loan to a user
   */
   private void giveShortLoan()
   {
      String id = io.getID();
      String anAuthor = io.getAuthor();
      String aTitle = io.getTitle();
      
      System.out.println("Is granted: " + system.grantShortLoan(id, anAuthor, aTitle));
      System.out.println();          
      
   }
   
   /*
   * A method that grants a long loan to a user
   */
   private void giveLongLoan()
   {
      String id = io.getID();
      String anAuthor = io.getAuthor();
      String aTitle = io.getTitle();
      
      System.out.println("Is granted: " + system.grantLongLoan(id, anAuthor, aTitle));
      System.out.println();          
      
   }
   
   /*
   * A method that returns a loaned book back to the library
   */
   private void returnBook()
   {
      String id = io.getID();
      String anAuthor = io.getAuthor();
      String aTitle = io.getTitle();
      
      System.out.println("Is returned: " + system.returnBook(id, anAuthor, aTitle));
      System.out.println();
   }
   
   /*
   * A method retrieves books by a given author
   */
   private void returnBooksByAuthor()
   {
      String anAuthor = io.getAuthor();
      
      System.out.println(system.getBookByAuthor(anAuthor));
      System.out.println();
   }
   
   /*
   * A method that retrieves books by a given title
   */
   private void returnBooksByTitle()
   {
      String aTitle = io.getTitle();
      
      System.out.println(system.getBookByTitle(aTitle));
      System.out.println();
   }
   
   /*
   * A method that retrieves books by a given classification code
   */
   private void returnBooksByClassCode()
   {
      String classCode = io.getClassCode();
      
      System.out.println(system.getBookByClassificationCode(classCode));
      System.out.println();
   }
   
   /*
   * A method that list all the books in the library catalogue
   */
   private void listAllBooks()
   {
      System.out.println(system.listAllBooks());
      System.out.println();
   }
   
   /*
   * A method that lists all the users in the system
   */
   private void listAllUsers()
   {
      System.out.println(system.listAllUsers());
      System.out.println();
   }
   
   /*
   * A method that lists all the loans ever made
   */
   private void listAllLoans()
   {
      System.out.println(system.listAllLoans());
      System.out.println();
   }
   
   /*
   * A method that lists all the overdue books
   */
   private void listAllBooksOverdue() throws ParseException
   {
      System.out.println(system.listAllBooksOverdue());
      System.out.println();
   }
}

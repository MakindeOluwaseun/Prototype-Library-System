public abstract class User
{
   private String name; //the name of the User
   private String id; //the unique identification number of the User
   private int maximumBorrowLimit; //the maximum borrow limit of the User
   private int count; //indicates the current number of books borrowed by a user
   private Book[] bookList; //the User's list of borrowed books
   
   
   /*
   * A user-defined constructor method
   */
   public User(String aName, String anID, int aBorrowLimit)
   {
      name = aName;
      id = anID;
      maximumBorrowLimit = aBorrowLimit;
      bookList = new Book[maximumBorrowLimit];
      count = 0;
      
   }
   
   /*
   * A method that gets the name of a specified user
   * @retrun the name of the specified user
   */
   public String getName()
   {
      return name;
   }
   
   /*
   * A method that gets the identification number of a particular user
   * @return the identification number of a specified user
   */
   public String getID()
   {
      return id;
   }
   
   /*
   * A method that gets the maximum borrow limit of a specified user
   * @return the maximum borrow limit of the specified user
   */
   public int getMaxBorrowLimit()
   {
      return maximumBorrowLimit;
   }
   
   /*
   * A method that returns the number of books that are currently in the user's possession
   * @return the current number of books in a user's possession
   */
   public int getNoOfBooksBorrowed()
   {
      return count;
   }
   
   /*
   * A method that adds a book to the user's list of borrowed books and sets the user of the book
   * to the specified user
   * @param aBook the book to be added to the user's list of borrowed books
   * @return a boolean value of true if the book has been added else false
   */
   public boolean addBookToList(Book aBook)
   {
      boolean bookAdded = false;
      
      if((this.getNoOfBooksBorrowed() < this.getMaxBorrowLimit()) && (aBook.getUser() == null))
      {
         bookList[this.getNoOfBooksBorrowed()] = aBook;
         count++;
         bookAdded = true;
         aBook.setUser(this);
      }
      
      return bookAdded;
      
   }
   
   /*
   * A method that removes a book from a user's list of borrowed books and un-assigns the user
   * from the book
   * @param aBook the book to be removed from the user's list of borrowed books
   * @return a boolean value of false if the book has beem removed otherwise false
   */
   public boolean removeBookFromList(Book aBook)
   {
      boolean bookRemoved = false; //flag boolean as false
      
      for(int i = 0; i < bookList.length; i++)
      {
         if(aBook == bookList[i])
         {
            bookList[i] = null;
            count--;
            bookRemoved = true;
            aBook.setUser(null);
         }
      }
      
      return bookRemoved;       
   }
   
   public String printBorrowList()
   {
      StringBuilder stb = new StringBuilder();
      int bookNumber = 1; //a variable which increments as each book is appended to the string builder
      
      //A for loop to browse through the contents of the borrow list
      for(int i = 0; i < bookList.length; i++)
      {
         stb.append(bookNumber + "." + "\n" + bookList[i] + "\n\n");
         bookNumber++;
      }
      
      return stb.toString(); //converts the StringBuilder object to a string
   }
   
   /*
   * A method that prints the current state of a user
   * @return the current state of a user
   */
   public String toString()
   {
      String state = "Name: " + this.getName() + "\n" + "Identification Number: " + this.getID()
                     + "\n\n" + "List of currently borrowed books: " + "\n" + this.printBorrowList()
                     + "Number of books currently borrowed: " + this.getNoOfBooksBorrowed()
                     + "Maximum borrow limit: " + this.getMaxBorrowLimit() + "\n";
      return state;
   }
}
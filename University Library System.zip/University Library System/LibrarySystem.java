//packages
import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;


public class LibrarySystem
{
   private ArrayList<User> userList;
   private ArrayList<Book> bookList;
   private ArrayList<Loan> loanList;
   
   /*
   * A user-defined constructor method
   */
   public LibrarySystem()
   {
      userList = new ArrayList<User>();
      bookList = new ArrayList<Book>();
      loanList = new ArrayList<Loan>();
   }
   
   /*
   * A method that adds a user to the user list
   * @param aUser the user to be added to the list
   * @return a boolean value of true if the user has been successfully added else false
   */
   public boolean addAUser(User aUser)
   {
      return userList.add(aUser);
   }
   
   /*
   * A method that removes a user from the user list using a given identification number
   * @param anID the identification number of the User to be removed from the user list
   * @return a boolean value of true if the action is successful else false
   */
   public boolean removeUser(String anID)
   {
      boolean result = false; //flags boolean as false
      for(int i = 0; i < userList.size(); i++)
      {
         if(userList.get(i).getID().equals(anID) == true)
         {
            userList.remove(userList.get(i));
            result = true;
            i = userList.size();
         }
      }
      
      return result;
   }
   
   /*
   * A method that adds a book to the library catalogue
   * @param aBook the book to be added to the library catalogue
   * @return a boolean value of true if the action is successful else false
   */
   public boolean addBook(Book aBook)
   {
      return bookList.add(aBook);
   }
   
   /*
   * A method that adds a loan to the loan list
   * @param aLoan the loan to be added to the loan list
   * @return a boolean value of true if the action is successful else false
   */
   public boolean addLoan(Loan aLoan)
   {
      return loanList.add(aLoan);
   }
   
   /*
   * A method that removes a book from the library catalogue
   * @param anAuthor the author of the book to be removed
   * @param aTitle the title of the book to be removed
   * @param classCode the classification code of the book to be removed
   * @return a boolean value of true if the action is successful else false
   */
   public boolean removeBook(String anAuthor, String aTitle, String classCode)
   {
      boolean result = false; //flags boolean as false
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if((bookList.get(i).getAuthor().equals(anAuthor) == true) && (bookList.get(i).getTitle().equals(aTitle) == true) && (bookList.get(i).getClassificationCode().equals(classCode) == true) && (bookList.get(i).getUser() == null))
         {
            bookList.remove(bookList.get(i));
            result = true;
            i = bookList.size();
         }
      }
      
      return result;
   }
   
   /*
   * A method that retrieves a user from the user list
   * @param anID the identification number of the user to be retrieved
   * @return the specified user if anID matched user's in list else null indication nothing
   */
   public User getUser(String anID)
   {
      User aUser = null;
      for(int i = 0; i < userList.size(); i++)
      {
         if(userList.get(i).getID().equals(anID) == true)
         {
            aUser = userList.get(i);
            i = userList.size();
         }
      }
      
      return aUser;
   }
   
   /*
   * A method that retrieves an available book from the book list given a specified author and title
   * @param anAuthor the auhtor of the book to be retrieved
   * @param aTitle the title of the book to be retrieved
   * @return a book if found else null if nothing is found
   */
   public Book getAnAvailableBook(String anAuthor, String aTitle)
   {
      Book aBook = null;
      for(int i = 0; i < bookList.size(); i++)
      {
         if((bookList.get(i).getAuthor().equals(anAuthor) == true) && (bookList.get(i).getTitle().equals(aTitle) == true) && (bookList.get(i).getUser() == null))
         {
            aBook = bookList.get(i);
            i = bookList.size();
         }
      }
      
      return aBook;
   }
      
   /*
   * A method that grants a short term loan to a user given a specified user and book
   * @param anID the identification number of the user the loan is to be granted to
   * @param anAuthor the author of the book to be loaned to the user
   * @param aTitle the title of the book to be loaned to the user
   * @return a boolean value of true if the action is successful else false
   */
   public boolean grantShortLoan(String anID, String anAuthor, String aTitle)
   {
      boolean result = false;
      
      User aUser = this.getUser(anID);
      Book aBook = this.getAnAvailableBook(anAuthor, aTitle);
      
      if((aUser != null) && (aBook != null) && (aUser.getNoOfBooksBorrowed() < aUser.getMaxBorrowLimit()))
      {
         ShortLoan aLoan = new ShortLoan(aUser, aBook);
         this.addLoan(aLoan);
         result = true;
      }
      
     /* if(aUser == null)
      {
         System.out.println("User does no exist");
      }
      
      if(aBook == null)
      {
         System.out.println("Either the book does not exist or it isn't currently available for loan");
      }
      
      if(aUser.getNoOfBooksBorrowed() <= aUser.getMaxBorrowLimit())
      {
         System.out.println("Borrow Limit reached");
      }*/
      
      
      return result;
   }
   
   /*
   * A method that grants a long term loan to a user given a specified user and book
   * @param anID the identification number of the user the loan is to be granted to
   * @param anAuthor the author of the book to be loaned to the user
   * @param aTitle the title of the book to be loaned to the user
   * @return a boolean value of true if the action is successful else false
   */
   public boolean grantLongLoan(String anID, String anAuthor, String aTitle)
   {
      boolean result = false;
      
      User aUser = this.getUser(anID);
      Book aBook = this.getAnAvailableBook(anAuthor, aTitle);
      
      if((aUser != null) && (aBook != null) && (aUser.getNoOfBooksBorrowed() < aUser.getMaxBorrowLimit()))
      {
         LongLoan aLoan = new LongLoan(aUser, aBook);
         this.addLoan(aLoan);
         result = true;
      }
      
      /*if(aUser == null)
      {
         System.out.println("User does no exist");
      }
      
      if(aBook == null)
      {
         System.out.println("Either the book does not exist or it isn't currently available for loan");
      }
      
      if(aUser.getNoOfBooksBorrowed() >= aUser.getMaxBorrowLimit())
      {
         System.out.println("Borrow Limit reached");
      }*/
      
      return result;
   }
   
   /*
   * A method that grants returns a book back to the library
   * @param anID the identification number of the user who loaned the book
   * @param anAuthor the author of the book which was loaned
   * @param aTitle the title of the book which was loaned
   * @return a boolean value of true if the action is successful else false
   */
   public boolean returnBook(String anID, String anAuthor, String aTitle)
   {
      boolean result = false;
      
      User aUser = this.getUser(anID);
      Book aBook = null;
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if((bookList.get(i).getAuthor().equals(anAuthor) == true) && (bookList.get(i).getTitle().equals(aTitle) == true) && (bookList.get(i).getUser() == aUser))
         {
            aBook = bookList.get(i);
            i = bookList.size();
         }
      }
      
      if((aUser != null) && (aBook != null))
      {
         aUser.removeBookFromList(aBook);
         result = true;
      }
      
      /*if(aUser == null)
      {
         System.out.println("User does not exist");
      }
      
      if(aBook == null)
      {
         System.out.println("Either the book does not exist or it wasn't lent by the specfied user");
      }*/
      
      return result;
   }
   
   /*
   * A method that gets the available number of books in the library catalogue by a given author
   * @param anAuthor the author of the book which is used to make the inquiry
   * @param the current number of books in the library catalogue by the specified author
   */
   //helper method
   private int getAvailableBooks(String anAuthor)
   {
      int count = 0;
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if((bookList.get(i).getAuthor().equals(anAuthor) == true) && (bookList.get(i).getUser() == null))
         {
            count++;
         }
      }
      
      return count;
   }
   
   /*
   * A method that retrieves all the books in the library by a given author and the number of available copies
   * @param anAuthor the author of the book(s) to be retrieved
   * @return a list of books by a given author if any
   */
   public String getBookByAuthor(String anAuthor)
   {
      StringBuilder stb = new StringBuilder();
      
      int bookCount = 1; //a variable which increments as each book is appended to the string builder object
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if(bookList.get(i).getAuthor().equals(anAuthor) == true)
         {
            stb.append("Book " + bookCount + "." + "\n" + bookList.get(i) + "\n");
            bookCount++;
         }
      }
      
      stb.append("No of available copies: " + this.getAvailableBooks(anAuthor));
            
      if(stb.toString().equals("") == true)
      {
         System.out.println("No results found");
      }
      
      return stb.toString();   

   }
   
   /*
   * A method that retrieves all the books in the library by a given title
   * @param anTitle the title of the book(s) to be retrieved
   * @return a list of books by a given title if any
   */
   public String getBookByTitle(String aTitle)
   {
      StringBuilder stb = new StringBuilder();
      
      int bookCount = 1; //a variable which increments as each book is appended to the string builder object
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if(bookList.get(i).getTitle().equals(aTitle) == true)
         {
            stb.append("Book " + bookCount + "." + "\n" + bookList.get(i) + "\n");
            bookCount++;
         }
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("No results found");
      }
      
      return stb.toString();   
   }
   
   /*
   * A method that retrieves all the books in the library by a given classification code
   * @param classCode the classification code of the book(s) to be retrieved
   * @return a list of books by a given classification code if any
   */
   public String getBookByClassificationCode(String classCode)
   {
      StringBuilder stb = new StringBuilder();
      
      int bookCount = 1; //a variable which increments as each book is appended to the string builder object
      
      for(int i = 0; i < bookList.size(); i++)
      {
         if(bookList.get(i).getClassificationCode().equals(classCode) == true)
         {
            stb.append("Book " + bookCount + "." + "\n" + bookList.get(i) + "\n");
            bookCount++;
         }
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("No results found");
      }
      
      return stb.toString();   
   }
   
   /*
   * A method that lists all the books in the library catalogue
   * @return a list of books if any
   */
   public String listAllBooks()
   {
      StringBuilder stb = new StringBuilder();
      int bookNumber = 1; //a variable that increments as each book is appended to the string builder object
      
      for(int i = 0; i < bookList.size(); i++)
      {
         stb.append("Book " + bookNumber + "." + "\n" + bookList.get(i) + "\n");
         bookNumber++;
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("There are no books in the list");
      }
      
      return stb.toString();
   }
   
   /*
   * A method that lists all the users in the user list
   * @return a list of users if any
   */
   public String listAllUsers()
   {
      StringBuilder stb = new StringBuilder();
      int userNumber = 1; //a variable that increments as each user is appended to the string builder object
      
      for(int i = 0; i < userList.size(); i++)
      {
         stb.append("User " + userNumber + "." + "\n" + userList.get(i) + "\n");
         userNumber++;
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("There are no users in the list");
      }
      
      return stb.toString(); 
   }
   
   /*
   * A method that lists all the loans in the loan list
   * @return a list of loans if any
   */
   public String listAllLoans()
   {
      StringBuilder stb = new StringBuilder();
      int loanNumber = 1; //a variable that increments as each loan is appended to the string builder object
      
      for(int i = 0; i < loanList.size(); i++)
      {
         stb.append("Loan " + loanNumber + "." + "\n" + loanList.get(i) + "\n");
         loanNumber++;
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("There are no loans in the list");
      }
      
      return stb.toString(); 
   }
   
   /*
   * A method that lists all the overdue books
   * @return a list of overdue books if any
   */
   public String listAllBooksOverdue() throws ParseException
   {
      StringBuilder stb = new StringBuilder();
      int loanNumber = 1; //a variable that increments as each loan is appended to the string builder object
     
      int missingYears = 1900; //missing years from the getYear() method of the Date class
      int missingMonth = 1; //missing month from the getMonth() method of the Date class
      Date aDate = new Date(); //today's date
      String stringDate = aDate.getDate() + "/" + (aDate.getMonth() + missingMonth) + "/"
      + (aDate.getYear() + missingYears);
      Date newDate = new SimpleDateFormat("dd/mm/yyyy", Locale.ENGLISH).parse(stringDate); //converts string to date

      
      for(int i = 0; i < loanList.size(); i++)
      {
         Date date = new SimpleDateFormat("dd/mm/yyyy", Locale.ENGLISH).parse(loanList.get(i).getLoanEndDate());
         if(newDate.after(date) == true)
         {
           stb.append("Overdue book " + loanNumber + "." + "\n" + loanList.get(i) + "\n");
           loanNumber++;
         }
      }
      
      if(stb.toString().equals("") == true)
      {
         System.out.println("There are no books overdue");
      }
      
      return stb.toString();
   }
           
}